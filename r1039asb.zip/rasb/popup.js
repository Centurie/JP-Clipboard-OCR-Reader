const DEFAULT_DOMAINS = ["animelok.com", "animekai.to", "gogoanime.hu"];

function updateStatus(msg) {
  const status = document.getElementById("status");
  status.innerText = msg;
  setTimeout(() => { status.innerText = ""; }, 3000);
}

function refreshSubtitleList() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { type: "GET_SUBTITLE_STATE" }, (response) => {
        if (chrome.runtime.lastError || !response) return;
        
        const select = document.getElementById("subtitleSelect");
        select.innerHTML = '<option value="">None</option>';
        
        response.files.forEach(file => {
          const opt = document.createElement("option");
          opt.value = file;
          opt.textContent = file;
          if (file === response.active) opt.selected = true;
          select.appendChild(opt);
        });
      });
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["jimakuApiKey", "allowedDomains"], (res) => {
    if (res.jimakuApiKey) document.getElementById("apiKey").value = res.jimakuApiKey;
    const domains = res.allowedDomains || DEFAULT_DOMAINS;
    document.getElementById("allowedDomains").value = domains.join("\n");
  });
  refreshSubtitleList();
});

document.getElementById("fileInput").addEventListener("change", async (e) => {
  const files = Array.from(e.target.files);
  if (!files.length) return;

  const fileData = await Promise.all(files.map(file => {
    return new Promise(resolve => {
      const reader = new FileReader();
      reader.onload = evt => resolve({ name: file.name, content: evt.target.result });
      reader.readAsText(file);
    });
  }));

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: "ADD_SUBTITLES",
        files: fileData
      }, () => {
        refreshSubtitleList();
        updateStatus(`Loaded ${files.length} file(s).`);
      });
    }
  });
});

document.getElementById("subtitleSelect").addEventListener("change", (e) => {
  const selected = e.target.value;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: "SET_ACTIVE_SUBTITLE",
        filename: selected
      });
    }
  });
});

document.getElementById("saveBtn").addEventListener("click", () => {
  const apiKey = document.getElementById("apiKey").value.trim();
  const rawDomains = document.getElementById("allowedDomains").value;
  const allowedDomains = rawDomains.split("\n").map(d => d.trim().toLowerCase()).filter(d => d.length > 0);
  chrome.storage.local.set({ jimakuApiKey: apiKey, allowedDomains }, () => {
    updateStatus("Settings Saved.");
  });
});