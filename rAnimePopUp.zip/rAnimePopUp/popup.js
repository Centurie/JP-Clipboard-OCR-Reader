document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('toggleSwitch');
  const statusText = document.getElementById('status-text');

  // Load current state (default to true if undefined)
  chrome.storage.local.get(['isEnabled'], (result) => {
    const isEnabled = result.isEnabled !== false;
    toggle.checked = isEnabled;
    statusText.textContent = isEnabled ? 'Enabled' : 'Disabled';
    statusText.style.color = isEnabled ? '#555' : '#cc0000';
  });

  // Save state on change
  toggle.addEventListener('change', () => {
    const isEnabled = toggle.checked;
    chrome.storage.local.set({ isEnabled: isEnabled });
    statusText.textContent = isEnabled ? 'Enabled' : 'Disabled';
    statusText.style.color = isEnabled ? '#555' : '#cc0000';
  });
});