chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "searchDictionary") {
    const text = request.text;
    
    fetch(`https://jisho.org/api/v1/search/words?keyword=${encodeURIComponent(text)}`)
      .then(res => res.json())
      .then(data => {
        if (data.data && data.data.length > 0) {
          sendResponse({ success: true, source: 'jisho', data: data });
        } else {
          return fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=ja|en`)
            .then(res => res.json())
            .then(trans => sendResponse({ success: true, source: 'translation', data: trans }))
            .catch(() => sendResponse({ success: false }));
        }
      })
      .catch((error) => {
        console.error("Jisho API Error:", error);
        sendResponse({ success: false });
      });
    return true;
  }
});