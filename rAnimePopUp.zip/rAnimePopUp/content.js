(() => {
  let activePopup = null;
  let mouseX = 0;
  let mouseY = 0;
  let isExtensionEnabled = true;
  
  // Anti-flicker/glitch variables
  let lastPopupCloseTime = 0;
  let lastSearchedText = '';

  // Check initial state
  if (chrome.runtime?.id) {
    chrome.storage.local.get(['isEnabled'], (result) => {
      isExtensionEnabled = result.isEnabled !== false;
    });

    // Listen for changes from the popup toggle
    chrome.storage.onChanged.addListener((changes, namespace) => {
      if (changes.isEnabled) {
        isExtensionEnabled = changes.isEnabled.newValue;
        if (!isExtensionEnabled) {
          removePopup(); // Instantly close popup if turned off
        }
      }
    });
  }
  
  // Drag state variables
  let isDraggingPopup = false;
  let popupDragStartX = 0;
  let popupDragStartY = 0;

  // Track mouse coordinates to spawn the popup near the cursor on Ctrl+C
  document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  }, true);

  // Trigger 1: Text Selection (Mouse)
  document.addEventListener('mouseup', (e) => {
    if (!isExtensionEnabled) return;
    if (activePopup && activePopup.contains(e.target)) return;

    // FIX 1: Ignore clicks on interactive elements (Video players, buttons, links, etc.)
    // This prevents clicking "Play" from re-triggering the popup.
    const interactiveTags = ['VIDEO', 'BUTTON', 'INPUT', 'A', 'SVG', 'PATH'];
    if (interactiveTags.includes(e.target.tagName) || 
        e.target.closest('video, button, [role="button"], .controls, .vjs-control-bar, .ytp-chrome-bottom')) {
      return;
    }

    // FIX 2: Prevent immediate reopening. If the popup was closed in the last 500ms, ignore this mouseup.
    if (Date.now() - lastPopupCloseTime < 500) {
      return;
    }

    const selection = window.getSelection();
    const text = selection.toString().trim();

    if (!text || selection.rangeCount === 0) return;
    
    // FIX 3: If the user clicks elsewhere on the page, the old text is still selected.
    // Prevent reopening the exact same text if it was just closed.
    if (text === lastSearchedText && Date.now() - lastPopupCloseTime < 2000) {
      return;
    }

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
      
    removePopup();
    lastSearchedText = text;
    executeSearch(text, rect.left + 20, rect.bottom + 20);
  }, true);

  // Trigger 2: Clipboard Copy (Ctrl+C or Browser Extension Copy)
  document.addEventListener('copy', () => {
    if (!isExtensionEnabled) return;
    setTimeout(async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (!text.trim()) return;
        
        removePopup();
        lastSearchedText = text.trim();
        executeSearch(text.trim(), mouseX + 20, mouseY + 20);
      } catch (err) {
        console.error("Clipboard permission denied or unavailable.");
      }
    }, 50);
  }, true);

  // Close popup when clicking outside
  document.addEventListener('mousedown', (e) => {
    if (activePopup && !activePopup.contains(e.target)) {
      removePopup();
      lastPopupCloseTime = Date.now(); // Record the time of closing to prevent immediate reopen
    }
  }, true);

  // Global Drag Logic
  document.addEventListener('mousemove', (e) => {
    if (!isDraggingPopup || !activePopup) return;
    
    let newX = e.clientX - popupDragStartX;
    let newY = e.clientY - popupDragStartY;

    // Keep within screen bounds
    newX = Math.max(0, Math.min(newX, window.innerWidth - activePopup.offsetWidth));
    newY = Math.max(0, Math.min(newY, window.innerHeight - activePopup.offsetHeight));

    activePopup.style.left = `${newX}px`;
    activePopup.style.top = `${newY}px`;
  });

  document.addEventListener('mouseup', () => {
    if (isDraggingPopup && activePopup) {
      isDraggingPopup = false;
      document.body.style.userSelect = '';
      // Save position to localStorage
      localStorage.setItem('yomiPopupX', activePopup.style.left);
      localStorage.setItem('yomiPopupY', activePopup.style.top);
    }
  });

  function executeSearch(rawText, x, y) {
    removePopup(); // Ensure previous popup is completely gone
    renderLoadingState(rawText, x, y);

    const segmenter = new Intl.Segmenter('ja', { granularity: 'word' });
    const segments = Array.from(segmenter.segment(rawText)).filter(s => s.isWordLike);
    
    let query = rawText;
    if (segments.length > 0) {
      segments.sort((a, b) => b.segment.length - a.segment.length);
      query = segments[0].segment;
    }

    fetchTranslation(query, rawText);
  }

  function fetchTranslation(query, originalText) {
    if (!chrome.runtime?.id) {
      updatePopupWithError("Extension context invalidated. Refresh the page.");
      return;
    }

    chrome.runtime.sendMessage({ action: "searchDictionary", text: query }, (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        updatePopupWithError("No definition found.");
        return;
      }
      processAndRender(response, originalText);
    });
  }

  function processAndRender(response, fallbackText) {
    if (!activePopup) return;

    let data = { word: fallbackText, reading: '', tags: [], senses: [] };

    if (response.source === 'jisho' && response.data.data.length > 0) {
      const entry = response.data.data[0];
      const jp = entry.japanese[0] || {};
      data.word = jp.word || fallbackText;
      data.reading = jp.reading || '';
      if (entry.is_common) data.tags.push('Common');
      
      const maxSenses = Math.min(entry.senses.length, 3);
      for (let i = 0; i < maxSenses; i++) {
        const sense = entry.senses[i];
        if (i === 0 && sense.parts_of_speech.length > 0) {
          data.tags.push(sense.parts_of_speech[0]);
        }
        data.senses.push(sense.english_definitions.join('; '));
      }
    } else {
      const translation = response.data?.responseData?.translatedText || fallbackText;
      data.tags.push('Translation');
      data.senses.push(translation);
    }

    const tagsHtml = data.tags.map(t => `<span class="yomi-tag">${t}</span>`).join('');
    const defsHtml = data.senses.map(d => `<li class="yomi-def-item">${d}</li>`).join('');

    activePopup.innerHTML = `
      <div class="yomi-content">
        <div class="yomi-reading">${data.reading}</div>
        <div class="yomi-word-row">
          <span class="yomi-word">${data.word}</span>
          <button class="yomi-audio" title="Play Audio">🔊</button>
        </div>
        ${tagsHtml ? `<div class="yomi-tags">${tagsHtml}</div>` : ''}
        <div class="yomi-dict">
          <div class="yomi-dict-title">${response.source === 'jisho' ? 'JMDict' : 'Neural Translate'}</div>
          <ol class="yomi-definitions">${defsHtml}</ol>
        </div>
      </div>
    `;

    setupDrag(activePopup);
    setupAudio(activePopup, data.word);
  }

  function renderLoadingState(text, x, y) {
    const popup = document.createElement('div');
    popup.id = 'yomi-translator-root';

    const width = 360;
    let posX = x;
    let posY = y;

    // Check for saved position
    const savedX = localStorage.getItem('yomiPopupX');
    const savedY = localStorage.getItem('yomiPopupY');

    if (savedX && savedY) {
      posX = parseInt(savedX, 10);
      posY = parseInt(savedY, 10);
    } else {
      // Default offset: put it ABOVE the subtitle so it doesn't cover it
      posX = x;
      posY = y - 200; 
      if (posY < 0) posY = y + 20; // If too high, put it below instead
    }

    // Keep within screen bounds
    if (posX + width > window.innerWidth) posX = window.innerWidth - width - 15;
    if (posY + 200 > window.innerHeight) posY = window.innerHeight - 200 - 15;
    if (posX < 0) posX = 10;
    if (posY < 0) posY = 10;

    popup.style.left = `${posX}px`;
    popup.style.top = `${posY}px`;

    popup.innerHTML = `
      <div class="yomi-content">
        <div class="yomi-word-row" style="border-bottom: none; margin-bottom: 0;">
          <span class="yomi-word">${text}</span>
        </div>
        <div class="yomi-status">Fetching translation...</div>
      </div>
    `;

    const container = document.fullscreenElement || document.body;
    container.appendChild(popup);
    activePopup = popup;

    setupDrag(popup);
  }

  function setupDrag(popup) {
    const dragHandle = popup.querySelector('.yomi-word-row');
    if (!dragHandle) return;

    dragHandle.addEventListener('mousedown', (e) => {
      if (e.target.closest('.yomi-audio')) return; // Don't drag when clicking audio button
      isDraggingPopup = true;
      popupDragStartX = e.clientX - popup.getBoundingClientRect().left;
      popupDragStartY = e.clientY - popup.getBoundingClientRect().top;
      document.body.style.userSelect = 'none'; // Prevent text selection while dragging
    });
  }

  function setupAudio(popup, word) {
    const audioBtn = popup.querySelector('.yomi-audio');
    if (audioBtn) {
      audioBtn.addEventListener('click', () => {
        const utterance = new SpeechSynthesisUtterance(word);
        utterance.lang = 'ja-JP';
        window.speechSynthesis.speak(utterance);
      });
    }
  }

  function updatePopupWithError(message) {
    if (!activePopup) return;
    const statusEl = activePopup.querySelector('.yomi-status');
    if (statusEl) {
      statusEl.textContent = message;
      statusEl.style.color = "#cc0000";
    }
  }

  function removePopup() {
    if (activePopup) {
      activePopup.remove();
      activePopup = null;
    }
  }
})();