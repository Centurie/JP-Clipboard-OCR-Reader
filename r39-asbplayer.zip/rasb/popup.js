const DEFAULT_DOMAINS = ["animelok.com", "animekai.to", "gogoanime.hu"];

document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["jimakuApiKey", "allowedDomains"], (res) => {
    if (res.jimakuApiKey) document.getElementById("apiKey").value = res.jimakuApiKey;
    const domains = res.allowedDomains || DEFAULT_DOMAINS;
    document.getElementById("allowedDomains").value = domains.join("\n");
  });
});

document.getElementById("fileInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    const text = event.target.result;
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: "LOAD_RAW_SUBTITLE",
          filename: file.name,
          content: text
        });
        const status = document.getElementById("status");
        status.innerText = "Loaded: " + file.name;
        setTimeout(() => { status.innerText = ""; }, 3000);
      }
    });
  };
  reader.readAsText(file);
});

document.getElementById("saveBtn").addEventListener("click", () => {
  const apiKey = document.getElementById("apiKey").value.trim();
  const rawDomains = document.getElementById("allowedDomains").value;
  const allowedDomains = rawDomains.split("\n").map(d => d.trim().toLowerCase()).filter(d => d.length > 0);
  chrome.storage.local.set({ jimakuApiKey: apiKey, allowedDomains }, () => {
    const status = document.getElementById("status");
    status.innerText = "Settings Saved.";
    setTimeout(() => { status.innerText = ""; }, 2000);
  });
});