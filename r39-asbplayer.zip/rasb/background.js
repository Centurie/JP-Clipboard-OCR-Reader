function parseTime(t) {
  const parts = t.replace(',', '.').split(':');
  if (parts.length < 3) return 0;
  return (parseFloat(parts[0]) * 3600) + (parseFloat(parts[1]) * 60) + parseFloat(parts[2]);
}
function parseASS(raw) {
  const cues = [];
  for (const line of raw.split('\n')) {
    if (line.startsWith('Dialogue:')) {
      const parts = line.split(',');
      if (parts.length >= 10) {
        const start = parseTime(parts[1].trim());
        const end = parseTime(parts[2].trim());
        const text = parts.slice(9).join(',').replace(/\{.*?\}/g, '').replace(/\\N/g, '\n');
        cues.push({ start, end, text });
      }
    }
  }
  return cues;
}
function parseSRT(raw) {
  const cues = [];
  for (const block of raw.split(/\n\s*\n/)) {
    const lines = block.trim().split('\n');
    if (lines.length >= 3) {
      const timeMatch = lines[1].match(/(.*?)\s*-->\s*(.*)/);
      if (timeMatch) {
        cues.push({ start: parseTime(timeMatch[1].trim()), end: parseTime(timeMatch[2].trim()), text: lines.slice(2).join('\n') });
      }
    }
  }
  return cues;
}
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "CHECK_SITE_ALLOWED") {
    chrome.storage.local.get(["allowedDomains"], (res) => {
      const allowed = res.allowedDomains || ["animelok.com", "animekai.to"];
      const hostname = new URL(request.url).hostname.toLowerCase();
      sendResponse({ allowed: allowed.some(d => hostname.includes(d)) });
    });
    return true;
  }
  if (request.type === "FETCH_JIMAKU") {
    chrome.storage.local.get(["jimakuApiKey"], async (res) => {
      if (!res.jimakuApiKey) return sendResponse({ error: "Missing API Key" });
      try {
        const queryUrl = `https://jimaku.cc/api/entries/search?q=${encodeURIComponent(request.meta.title)}`;
        const searchRes = await fetch(queryUrl, { headers: { "Authorization": res.jimakuApiKey } });
        const data = await searchRes.json();
        if (!data.length) return sendResponse({ cues: [] });
        const fileUrl = data[0].download_url;
        const fileRes = await fetch(fileUrl, { headers: { "Authorization": res.jimakuApiKey } });
        const rawText = await fileRes.text();
        const cues = fileUrl.endsWith('.srt') ? parseSRT(rawText) : parseASS(rawText);
        sendResponse({ cues });
      } catch (err) { sendResponse({ error: err.message }); }
    });
    return true;
  }
});