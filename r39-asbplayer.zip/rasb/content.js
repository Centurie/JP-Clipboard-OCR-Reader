(function () {
  let activeCues = [];
  let videoElement = null;
  let syncOffset = 0;
  let bottomPercent = 10;

  function parseTime(t) {
    const parts = t.replace(',', '.').split(':');
    if (parts.length < 3) return 0;
    return (parseFloat(parts[0]) * 3600) + (parseFloat(parts[1]) * 60) + parseFloat(parts[2]);
  }

  function parseSRT(raw) {
    const cues = [];
    for (const block of raw.split(/\n\s*\n/)) {
      const lines = block.trim().split('\n');
      if (lines.length >= 3) {
        const timeMatch = lines[1].match(/(.*?)\s*-->\s*(.*)/);
        if (timeMatch) {
          cues.push({
            start: parseTime(timeMatch[1].trim()),
            end: parseTime(timeMatch[2].trim()),
            text: lines.slice(2).join('\n')
          });
        }
      }
    }
    return cues;
  }

  function parseASS(raw) {
    const cues = [];
    for (const line of raw.split('\n')) {
      if (line.startsWith('Dialogue:')) {
        const parts = line.split(',');
        if (parts.length >= 10) {
          const start = parseTime(parts[1].trim());
          const end = parseTime(parts[2].trim());
          const text = parts.slice(9).join(',').replace(/\{.*?\}/g, '').replace(/\\N/g, '\n');
          cues.push({ start, end, text });
        }
      }
    }
    return cues;
  }

  function disableNativeSubtitles() {
    if (!videoElement || !videoElement.textTracks) return;
    for (let i = 0; i < videoElement.textTracks.length; i++) {
      videoElement.textTracks[i].mode = 'disabled';
    }
  }

  function initObserver() {
    const checkVideo = () => {
      const video = document.querySelector("video");
      if (video && video !== videoElement) {
        videoElement = video;
        setupOverlay();
        bindVideoEvents();
        setupDragAndDrop();
        disableNativeSubtitles();
      }
    };

    const observer = new MutationObserver(checkVideo);
    observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
    checkVideo();
  }

  function setupOverlay() {
    if (document.getElementById("r39-overlay")) return;

    const overlayDiv = document.createElement("div");
    overlayDiv.id = "r39-overlay";
    overlayDiv.style.bottom = bottomPercent + "%";
    
    const subtitleSpan = document.createElement("span");
    subtitleSpan.id = "r39-text";
    
    ['mousedown', 'mouseup', 'click', 'dblclick', 'pointerdown', 'pointerup', 'touchstart', 'touchend'].forEach(evt => {
      subtitleSpan.addEventListener(evt, e => {
        e.stopPropagation();
        e.stopImmediatePropagation();
      }, true);
    });

    overlayDiv.appendChild(subtitleSpan);

    const parent = videoElement.parentElement || document.body;
    if (getComputedStyle(parent).position === "static") {
      parent.style.position = "relative";
    }
    parent.appendChild(overlayDiv);

    if (!document.getElementById("r39-dropzone")) {
      const dropzone = document.createElement("div");
      dropzone.id = "r39-dropzone";
      dropzone.innerText = "📥 Drop .srt / .ass anywhere";
      document.body.appendChild(dropzone);
    }
  }

  function showLoaded(dropzone) {
    if (!dropzone) return;
    dropzone.innerText = "Loaded";
    setTimeout(() => { dropzone.style.display = "none"; }, 2000);
  }

  function setupDragAndDrop() {
    const dropzone = document.getElementById("r39-dropzone");

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(evt => {
      window.addEventListener(evt, e => {
        e.preventDefault();
        e.stopPropagation();
      }, true); 
    });

    window.addEventListener('dragenter', () => {
      if (dropzone) {
        dropzone.style.display = "block";
        dropzone.classList.add('dragover');
        if (dropzone.innerText === "Loaded") {
          dropzone.innerText = "📥 Drop .srt / .ass anywhere";
        }
      }
    }, true);

    window.addEventListener('dragleave', (e) => {
      if (!e.clientX && !e.clientY && dropzone) {
        dropzone.classList.remove('dragover');
        dropzone.style.display = "none";
      }
    }, true);

    window.addEventListener('drop', e => {
      if (dropzone) {
        dropzone.classList.remove('dragover');
        dropzone.style.display = "none";
      }
      
      const dt = e.dataTransfer;
      if (dt && dt.files && dt.files.length > 0) {
        const file = dt.files[0];
        const reader = new FileReader();
        reader.onload = (evt) => {
          const raw = evt.target.result;
          activeCues = file.name.endsWith('.srt') ? parseSRT(raw) : parseASS(raw);
          disableNativeSubtitles();
          if (dropzone) {
            dropzone.style.display = "block";
            showLoaded(dropzone);
          }
        };
        reader.readAsText(file);
      }
    }, true);
  }

  function bindVideoEvents() {
    videoElement.addEventListener("timeupdate", () => {
      disableNativeSubtitles();
      if (!activeCues.length) return;
      const t = videoElement.currentTime + syncOffset;
      const cue = activeCues.find(c => t >= c.start && t <= c.end);
      const textSpan = document.getElementById("r39-text");
      if (textSpan) textSpan.innerText = cue ? cue.text : "";
    });
  }

  function bindShortcuts() {
    window.addEventListener("keydown", (e) => {
      if (!e.ctrlKey) return;
      
      if (e.key === "]") syncOffset += 0.5;
      if (e.key === "[") syncOffset -= 0.5;
      
      if (e.key === "ArrowUp") {
        e.preventDefault();
        bottomPercent = Math.min( bottomPercent + 2, 80 );
        const overlayDiv = document.getElementById("r39-overlay");
        if (overlayDiv) overlayDiv.style.bottom = bottomPercent + "%";
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        bottomPercent = Math.max( bottomPercent - 2, 2 );
        const overlayDiv = document.getElementById("r39-overlay");
        if (overlayDiv) overlayDiv.style.bottom = bottomPercent + "%";
      }
    });
  }

  initObserver();
  bindShortcuts();

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "LOAD_RAW_SUBTITLE") {
      activeCues = msg.filename.endsWith('.srt') ? parseSRT(msg.content) : parseASS(msg.content);
      disableNativeSubtitles();
      const dropzone = document.getElementById("r39-dropzone");
      if (dropzone) {
        dropzone.style.display = "block";
        showLoaded(dropzone);
      }
    }
  });
})();